<?php 
$link = mysqli_connect("127.0.0.1", "root", "", "flower-shop");

?>
<html>
<head>
    <meta charset="utf-8">
    <title>Главная</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <script src="js/script.js"></script>
</head>
<body>
<header>
    <div id="logo" onclick="slowScroll('#top')">
        <span>Flower shop</span>
    </div>
    <div id="about">
        <a href="index.php" title="Главная" onclick="slowScroll('#main')">Главная</a>
        <a href="cc.php" title="Каталог">Каталог</a>
        <a href="#" title="Возможности" onclick="slowScroll('#main')">Возможности</a>
        <a href="#" title="Преимущества" onclick="slowScroll('#overview')">Преимущества</a>
        <a href="#" title="Связь" onclick="slowScroll('#contacts')">Связь</a>
        <?php
          if ($_COOKIE['user'] == ''):
        ?>
        <a href="" title="Авторизация"></a>
        <?php else: ?>
        <a href="php/admin.php" title="Авторизация">
           <?=$_COOKIE['user']?></a>
        <?php endif; ?>
    </div>
</header>
    <div id="top">
        <h1>Наполните уютом</h1>
        <h3>своё пространство!</h3>
    </div>

    <div id="main">
        <div class="intro">
            <h2>Мы поможем Вам!</h2>
            <span>Большой выбор растений для простора фантазии</span>
        </div>
        <div class="text">
            <span>У нас большой ассортимент цветов и аранжировочной зелени, который мы стараемся поддерживать круглый год, постоянно удивляя любимых клиентов новинками. Мы работаем с лучшими производителями цветов в России, Голландии, Эквадоре, для нас важно качество продукции.</span>
        </div>
    </div>

    <div id="overview">
        <h2>С нами всё проще!</h2>
        <h4>Наши специалисты помогут Вам подобрать цветы к Вашему пространству.</h4>

        <div class="img">
            <img src="https://idei.club/uploads/posts/2022-09/1663652793_1-idei-club-p-zelen-v-interere-kvartiri-dizain-2.jpg" alt="">
            <span>рпро</span>
        </div>
        <div class="img">
            <img src="https://mykaleidoscope.ru/uploads/posts/2021-03/1615785798_29-p-zelen-v-interere-obraz-34.jpg" alt="">
            <span>амам</span>
        </div>
        <div class="img">
            <img src="https://sdelano.ru/upload/medialibrary/bad/5-2.jpg" alt="">
            <span>смам</span>
        </div>
        <div class="img">
            <img src="https://idei.club/uploads/posts/2021-09/1631534199_31-idei-club-p-tsveti-v-kvartire-interer-krasivo-foto-31.jpg" alt="">
            <span>амам</span>
        </div>
    </div>

    <div id="contacts">
        <center><h5>Обратная связь</h5></center>
            <form id="form_input">
                <b><label for="name">Имя<span>*</span></label><br><br></b>
                <input type="text" placeholder="Введите имя" name="name" id="name"><br><br>
                <b><label for="email">Ваша почта<span>*</span></label><br><br></b>
                <input type="email" placeholder="Введите email" name="email" id="email"><br><br>
                <b><label for="message">Сообщение<span>*</span></label><br><br></b>
                <textarea placeholder="Введите Ваше сообщение" name="message" id="message"></textarea><br><br>
            <div id="mess_send" class="btn">Отправить</div>
            </form>
    </div>

<script> 
function slowScroll(id){
    $('html, body').animate({
        scrollTop: $(id).offset().top
    }, 500);
}

$(document).on("scroll", function() {
    if($(window).scrollTop() === 0)
        $("header").removeClass("fixed");
    else
        $("header").attr("class", "fixed");
});</script>
</body>
</html>