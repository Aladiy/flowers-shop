<?php 
$mysql = mysqli_connect("127.0.0.1", "root", "", "flower-shop");
$imge = mysqli_query($mysql, "SELECT `image` FROM `flowers`");
$ttle = mysqli_query($mysql, "SELECT `title` FROM `flowers`");
$prce = mysqli_query($mysql, "SELECT `price` FROM `flowers`");


?>
<html>
<head>
    <meta charset="utf-8">
    <title>Каталог</title>
	<link href="D:\program files\ospanel\domains\flowers-shop\php\check.php">
    <link rel="stylesheet" href="css/cc.css">
	<script src="https://kit.fontawesome.com/3d0e27e432.js"></script>
    <script src="js/script.js"></script>
</head>
<body>
<header>
    <div id="logo" onclick="slowScroll('#top')">
        <span>Flower shop</span>
    </div>
    <div id="about">
        <a href="index.php" title="Главная" onclick="slowScroll('#main')">Главная</a>
        <a href="#" title="Каталог" onclick="slowScroll('#catalog')">Каталог</a>
       <!-- <a href="#" class="fas fa-shopping-cart" title="Корзина">Корзина</a>-->
        <?php
          if ($_COOKIE['user'] == ''):
        ?>
        <a href="indx.php" title="Авторизация">Войти</a>
        <?php else: ?>
        <a href="php/admin.php" title="Авторизация">
           <?=$_COOKIE['user']?></a>
           <a href="php/exit.php" title="Авторизация">Выйти<?=$_COOKIE['user']==''?></a>
        <?php endif; ?>
      </div>
    
<button class="cart" id="cart">
     <a href="cart.php" class="btn">Корзина</a>
    </button>

</header>
    <div id="top">
        <h1>Каталог</h1>
        <h3>домашних растений</h3>
    </div>
    
<div id="catalog">
    <div class="cards">
    <?php
		while($result = mysqli_fetch_assoc($imge) and $result1 = mysqli_fetch_assoc($prce)
        and $result2 = mysqli_fetch_assoc($ttle)){
			?>
        <!-- Карточка товара -->
        <div class="card">
            <!-- Верхняя часть -->
            <div class="card__top">
                <!-- Изображение-ссылка товара -->
                <a href="#" class="card__image">
                <img
                    src="image/<?php echo $result['image']; ?>.jpg"
                    alt=""/>
                </a>
            </div>
            <!-- Нижняя часть -->
            <div class="card__bottom">
    <!-- Ссылка-название товара -->
    <a href="#" class="card__title" name="ttle">
    <?php echo $result2['title']; ?></a>
      <div class="card__price">
    <div class="card__price--common" name="prce">
    <?php echo $result1['price']; ?>
    </div>
        </div>
    <!-- Кнопка добавить в корзину -->
    <form action="cart.php" method="post">
    <button class="card__add">
        <ion-icon name="cart-outline"></ion-icon>
    </button>
        </form>
            </div>
        </div>

           <?php
		}
	?>
        </div>
    </div>

</div> 
<!--
<div id="popup">
  <div class="content">
    <ion-icon name="cart-outline"></ion-icon>
    <h2>Корзина</h2>
    <div class="inputBox">
    <a href="#" class="card__title">
    <?php //echo $result3['flower']; ?></a>
    <div class="card__price--common">
    <?php //echo $result4['price']; ?>
    </div>
    <a class="close" onclick="php/close.php" >Удалить товар<img src=""></a><br>
   <!-- <form action="php/cart.php" method="post">
      <input type="submit" value="Вернуться к покупкам" class="btn">
  </form>-->
      <!--<input type="submit" value="Оформить заказ" class="btn">-->
   <!-- </div>
  </div>
    <a class="close" onclick="popupToggle();" ><ion-icon name="close-outline"> <img src=""></a>-->


<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script> 
function slowScroll(id){
    $('html, body').animate({
        scrollTop: $(id).offset().top
    }, 500);
}

$(document).on("scroll", function() {
    if($(window).scrollTop() === 0)
        $("header").removeClass("fixed");
    else
        $("header").attr("class", "fixed");
});
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
</body>
</html>