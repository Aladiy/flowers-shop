<?php
$login = filter_var(trim($_POST['login']));
$pass = filter_var(trim($_POST['pass']));

$pass = md5($pass."trtfdgj5");

$mysql = new mysqli('localhost', 'root', '', 'flower-shop');
$result = $mysql->query("SELECT * FROM `user` WHERE `login`= '$login' AND `pass` = '$pass'");
  $user = $result->fetch_assoc();

if(count($user)==0){
    echo "Такой пользователь не найден";
    exit();
}
/*
if ($user[`name`] == 'admin' and $user[`pass`] == 'admin')
  {
    header("Location: /php/adminpanel.php");
    echo 'я админ';
  }*/
setcookie('user', $user['name'], time() + 3600*24, "/");

$mysql->close();

header('Location: /cc.php');


?>