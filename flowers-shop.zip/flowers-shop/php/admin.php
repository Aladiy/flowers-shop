<?php
$mysql = new mysqli('localhost', 'root', '', 'flower-shop');
$result = $mysql->query("SELECT * FROM `user` WHERE `login`= '$login' AND `pass` = '$pass'");
  $user = $result->fetch_assoc();
if ($_COOKIE['user']=='admin')
  {
    header("Location: /php/adminpanel.php");
  }
else {
  header("Location: /cc.php");
}

$mysql->close();
?>