<?php $mysql = new mysqli('127.0.0.1','root','','flower-shop');
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="css/style-admin.css">
	<title>Административная панель</title>
</head>
<body>
<!-- 
1) отображение - SELECT
2) добавление - INSERT INTO
3) редактирование - UPDATE
4) удаление - DELETE
-->
<p>я админ</p>
<table border="1" cellspacing="0" cellpadding="10">
	<tr>
		<td>id</td>
		<td>Название</td>
		<td>Цена</td>
		<td>Картинка</td>
	</tr>
	<?php 
		$adds = mysqli_query($mysql, "SELECT * FROM `flowers`");
		while ($row = mysqli_fetch_assoc($adds)) { ?>
			<tr>
				<td><?php echo $row['id']; ?></td>
				<td><?php echo $row['title']; ?></td>
				<td><?php echo $row['price']; ?></td>
                <td><?php echo $row['image']; ?></td>
				<td>
					<form method="post">
						<input type="text" name="title" value="<?php echo $row['title']; ?>">
						<input type="text" name="price" value="<?php echo $row['price']; ?>">
						<input type="text" name="image" value="<?php echo $row['image']; ?>">
						<input type="number" name="idedit" value="<?php echo $row['id']; ?>" 
						style="display: none;">
						<input type="submit" name="edit" value="Изменить">
					</form>
					<?php 
						if (isset($_POST['edit'])) {
							$title = $_POST['title'];
							$price = $_POST['price'];
							$image = $_POST['image'];
							$id = $_POST['idedit'];

							mysqli_query($mysql, "UPDATE `flowers`
								SET `price`='$price', `title`='$title', `image`='$image'
								WHERE `id`='$id'");
							header("location: /cc.php");
						}
					?>
				</td>
			</tr>
		<?php }

	?>
</table>


<!-- Удаление данных -->
<b><p>Удаление данных</p></b>
<form method="post">
	<input type="number" name="iddel"><br><br>
	<input type="submit" value="Удалить запись" name="delnews"><br><hr>
</form>
<?php 
	if (isset($_POST['delnews'])) {
		$idfordel = $_POST['iddel'];

		mysqli_query($mysql, "DELETE FROM `flowers`
			WHERE `id`='$idfordel'");
		header("location: /cc.php");
	}
?>

<!-- Ввод данных в БД -->
<b><p>Ввод данных в БД</p></b>
<form method="post">
	Название: <input type="text" name="title"><br><br>
	Цена: <input type="text" name="price"><br><br>
	Картинка: <input type="text" name="image"><br><br>
	<input type="submit" name="addnews"><br>
</form>
<?php 
	if (isset($_POST['addnews'])) {
		$title = $_POST['title'];
		$price = $_POST['price'];
		$image = $_POST['image'];
		// Если ничего не введено, то
		if ($title=="" or $price=="") {
			echo "Вы не ввели текст или заголовок";
		// Иначе добавляем запись (INSERT INTO)
		}else{
			mysqli_query($mysql, "INSERT INTO `flowers` (`title`, `price`, `image`)
			VALUES ('$title','$price', '$image')");
			header("location: /cc.php");
		}
	}
?>


</body>
</html>
<?php ob_end_flush(); ?>


<!-- https://www.youtube.com/watch?v=6q4YQ5p8vnc  -->
<!-- https://www.youtube.com/watch?v=Uazr6_08D00 -->