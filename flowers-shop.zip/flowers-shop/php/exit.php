<?php
    $_COOKIE['user']=='';
    setcookie('user', $user['name'], time() - 0*0, "/");
    header('Location: /cc.php');

?>