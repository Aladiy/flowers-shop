<?php
        $mysql = new mysqli('127.0.0.1','root','','flower-shop');
?>