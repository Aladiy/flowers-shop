<?php
    $flower = filter_var(trim($_POST['flower']));
    $price = filter_var(trim($_POST['price']));
    $count = filter_var(trim($_POST['count']));
    $login = $_COOKIE['user'];

    $mysql = new mysqli('localhost', 'root', '', 'flower-shop');

    $mysql->query("INSERT INTO `orders` (`flower`, `user`, `count`)
    VALUES('$flower', '$login', '$count')");

    $mysql->close();

    header('Location: /cc.php');
?>
