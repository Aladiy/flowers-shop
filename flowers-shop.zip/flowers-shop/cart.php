<?php 
$mysql = mysqli_connect("127.0.0.1", "root", "", "flower-shop");
$imge = mysqli_query($mysql, "SELECT `image` FROM `flowers` ORDER BY `id`");
$ttle = mysqli_query($mysql, "SELECT `title` FROM `flowers` ORDER BY `id`");
$prce = mysqli_query($mysql, "SELECT `price` FROM `flowers` ORDER BY `id`");

?>

<html>
<head>
    <meta charset="utf-8">
    <title>Каталог</title>
	<link href="D:\program files\ospanel\domains\flowers-shop\php\check.php">
    <link rel="stylesheet" href="css/style-cart.css">
	<script src="https://kit.fontawesome.com/3d0e27e432.js"></script>
    
</head>

<body>
<header>
    <div id="logo" onclick="slowScroll('#top')">
        <span>Flower shop</span>
    </div>
    <div id="about">
        <a href="index.php" title="Главная">Главная</a>
        <a href="cc.php" title="Каталог">Каталог</a>
        <?php
          if ($_COOKIE['user'] == ''):
        ?>
        <a href="indx.php" title="Авторизация">Войти</a>
        <?php else: ?>
        <a href="php/admin.php" title="Авторизация">
           <?=$_COOKIE['user']?></a>
           <a href="php/exit.php" title="Авторизация">Выйти<?=$_COOKIE['user']==''?></a>
        <?php endif; ?>
      </div>
</header>

<div id="overview">
<form action="php/order.php" method="post">

          <label class="form-label">Растение</label> <br> <br> 
          <select class="form-flower" name="flower" id="flower">
            <option value="">Выберите...</option>
            <?php while($result2 = mysqli_fetch_assoc($ttle) and $result1 = mysqli_fetch_assoc($prce)){ ?>
            <option><?php echo $result2['title']; ?></option>
            <?php } ?>
            </select>
            <div class="col-12">
                  <br> 
                  <label type="text" class="form-label">Количество: </label>  <br> <br> 
                <input type="text" class="form-count" name="count"
                id="count" placeholder="Введите число"><br>         
            </div>  <br>   <br>   <br> 
            <button class="btn" type="submit">Оформить заказ</button>
      </div>
    </div>
  </div>
</form>
<div>
    
</body>
</html>